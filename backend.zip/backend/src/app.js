
const express = require('express')
const cors = require('cors')
const morgan = require('morgan')
const mongoose = require('mongoose')

const requireAuth = require('./middleware/auth')
const { notFound, errorHandler } = require('./middleware/errorHandler')
const dashboardRoutes = require('./routes/dashboardRoutes')
const leadRoutes = require('./routes/leadRoutes')
const dealRoutes = require('./routes/dealRoutes')
const employeeRoutes = require('./routes/employeeRoutes')
const productRoutes = require('./routes/productRoutes')
const settingsRoutes = require('./routes/settingsRoutes')
const helpRoutes = require('./routes/helpRoutes')
const supportRoutes = require('./routes/supportRoutes')
const meRoutes = require('./routes/meRoutes')
const searchRoutes = require('./routes/searchRoutes')
const notificationRoutes = require('./routes/notificationRoutes')

const app = express()

app.use(cors({ origin: process.env.CLIENT_URL }))
app.use(express.json())
app.use(morgan('dev'))

app.get('/api/health', (req, res) => {
  const dbConnected = mongoose.connection.readyState === 1
  res.json({
    status: 'ok',
    database: dbConnected ? 'connected' : 'disconnected',
    dbName: mongoose.connection.name,
    time: new Date().toISOString()
  })
})

app.use('/api', requireAuth)
app.use('/api/dashboard', dashboardRoutes)
app.use('/api/leads', leadRoutes)
app.use('/api/deals', dealRoutes)
app.use('/api/employees', employeeRoutes)
app.use('/api/products', productRoutes)
app.use('/api/settings', settingsRoutes)
app.use('/api/help', helpRoutes)
app.use('/api/support', supportRoutes)
app.use('/api/me', meRoutes)
app.use('/api/search', searchRoutes)
app.use('/api/notifications', notificationRoutes)

app.use(notFound)
app.use(errorHandler)

module.exports = app