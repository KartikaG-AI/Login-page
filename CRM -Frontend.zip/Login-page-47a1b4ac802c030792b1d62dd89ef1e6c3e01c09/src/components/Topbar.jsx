import './Topbar.css'
import { useState } from 'react'
import {
  Search,
  Bell,
  ChevronDown,
  CalendarDays,
  UserRound,
  Settings,
  LogOut
} from 'lucide-react'

function Topbar() {
    const [profileOpen, setProfileOpen] = useState(false)
    return (
    <header className="topbar">

      {}
      <div className="topbar-left">

        <div className="breadcrumb">
          <span className="breadcrumb-active">Dashboard</span>
          <span className="breadcrumb-separator">/</span>
          <span>Overview</span>
        </div>

        {}
        <div className="search-box">
          <Search className="search-icon" size={18} />

          <input
            type="text"
            placeholder="Search leads, deals, contacts..."
          />

       
        </div>

      </div>


      {}
      <div className="topbar-right">

        {}
        <button className="notification-button">
          <Bell size={19} />

          <span className="notification-count">
            3
          </span>
        </button>

        <div className="topbar-divider"></div>


        {}
        <div className="profile-wrapper">

          <button
            className="profile-button"
            onClick={() => setProfileOpen(!profileOpen)}
          >

            <div className="profile-pic">
              J
            </div>

            <div className="profile-info">
              <span className="profile-name">
                Jeyka
              </span>

              <span className="profile-role">
                Admin
              </span>
            </div>

            <ChevronDown
              size={16}
              className={profileOpen ? 'chevron-up' : ''}
            />

          </button>


          {}
          {profileOpen && (
            <div className="profile-dropdown">

              <div className="dropdown-user">

                <div className="dropdown-avatar">
                  J
                </div>

                <div>
                  <strong></strong>
                  <span>Admin</span>
                </div>

              </div>


              <div className="dropdown-divider"></div>


              <button className="dropdown-item">
                <UserRound size={17} />
                <span>Profile</span>
              </button>

              <button className="dropdown-item">
                <Settings size={17} />
                <span>Settings</span>
              </button>


              <div className="dropdown-divider"></div>


              <button className="dropdown-item logout-item">
                <LogOut size={17} />
                <span>Logout</span>
              </button>

            </div>
          )}

        </div>

      </div>

    </header>
  )
}

export default Topbar