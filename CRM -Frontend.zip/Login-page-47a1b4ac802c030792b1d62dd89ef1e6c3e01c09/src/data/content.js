export const stats = [
  { value: "10,000+", label: "Businesses using CRM" },
  { value: "2M+", label: "Customer records managed" },
  { value: "4.8/5", label: "User satisfaction" },
  { value: "99.9%", label: "Platform uptime" },
];

export const features = [
  {
    title: "Lead & Contact Management",
    text: "Manage leads, contacts, accounts and customer information in one centralized system.",
  },
  {
    title: "Sales Pipeline",
    text: "Track opportunities through every stage and get a clear view of your sales pipeline.",
  },
  {
    title: "Activities & Follow-ups",
    text: "Schedule calls, meetings, tasks and follow-ups so important activities never get missed.",
  },
  {
    title: "Reports & Analytics",
    text: "Monitor sales performance, pipeline progress and business activities with clear reports.",
  },
  {
    title: "Workflow Automation",
    text: "Automate repetitive tasks, notifications and follow-up workflows to save time.",
  },
  {
    title: "Integrations",
    text: "Connect your CRM with email, communication tools, spreadsheets and other business applications.",
  },
];

export const steps = [
  {
    title: "Create your account",
    text: "Set up your CRM workspace and configure it according to your business workflow.",
  },
  {
    title: "Add your data",
    text: "Import or create leads, contacts, accounts and opportunities in one centralized system.",
  },
  {
    title: "Manage & grow",
    text: "Track your pipeline, manage activities, automate workflows and make data-driven decisions.",
  },
];

export const testimonials = [
  {
    name: "Jeka G.",
    role: "Business Owner",
    text: "The CRM gives us a clear view of our customers, opportunities and follow-ups in one place.",
  },
  {
    name: "Arun R.",
    role: "Sales Manager",
    text: "The pipeline and activity tracking make it much easier for our team to manage every opportunity.",
  },
  {
    name: "Mouni M.",
    role: "Business Administrator",
    text: "It is simple to manage customer information, tasks and sales activities without switching between different tools.",
  },
];

export const plans = [
  {
    name: "Free",
    price: "₹0",
    desc: "For individuals getting started",
    items: [
      "Contact management",
      "Basic pipeline",
      "Task management",
      "Basic reports",
    ],
  },
  {
    name: "Professional",
    price: "₹499",
    desc: "For growing teams",
    items: [
      "Advanced CRM",
      "Sales pipeline",
      "Workflow automation",
      "Reports & analytics",
      "Email integration",
    ],
    popular: true,
  },
  {
    name: "Business",
    price: "₹1,199",
    desc: "For teams with advanced needs",
    items: [
      "Advanced reports",
      "Custom workflows",
      "Multiple teams",
      "Integrations",
      "Priority support",
    ],
  },
];

export const faqs = [
  {
    q: "What is a CRM?",
    a: "A CRM helps businesses manage leads, contacts, customers, opportunities, activities and sales processes from one centralized platform.",
  },
  {
    q: "Can I manage both leads and existing customers?",
    a: "Yes, the CRM supports the complete customer journey from lead management to customer relationships and ongoing activities.",
  },
  {
    q: "Can I customize the CRM for my business?",
    a: "Yes, CRM workflows, pipelines, activities and other features can be configured according to different business requirements.",
  },
  {
    q: "Can I import my existing customer data?",
    a: "Yes, existing customer and business data can be imported into the CRM using supported formats such as CSV or Excel.",
  },
  {
    q: "Does the CRM support multiple users?",
    a: "Yes, teams can work together by assigning leads, opportunities, tasks and other activities to different users.",
  },
  {
    q: "Can I track my sales pipeline?",
    a: "Yes, opportunities can be organized by pipeline stages so teams can monitor progress and manage deals effectively.",
  },
];