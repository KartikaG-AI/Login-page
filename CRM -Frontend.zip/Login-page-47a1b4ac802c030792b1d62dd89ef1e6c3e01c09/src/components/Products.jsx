import { useState } from 'react'
import './Products.css'
function Products() {
  const [activeTab, setActiveTab] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('Active')
  const [showModal, setShowModal] = useState(false)
  const [offeringType, setOfferingType] = useState('Product')
  const [viewItem, setViewItem] = useState(null)
  const [editItem, setEditItem] = useState(null)
 const [offerings, setOfferings] = useState([
    {
  id: 7,
  type: 'Product',
  name: 'AI Chatbot Platform',
  code: 'AI-CHAT-001',
  category: 'AI Product',
  description: 'AI-powered chatbot platform for automating customer support and business communication.',
  price: 25000,
  billing: 'Yearly',
  status: 'Active'
},
    {
      id: 2,
      type: 'Service',
      name: 'Website Development',
      code: 'WEB-DEV-001',
      category: 'Web Development',
      description: 'Custom websites designed and developed for businesses.',
      price: 75000,
      duration: '30 Days',
      status: 'Active'
    }
  ])

  const filteredOfferings = offerings.filter((item) => {
    const matchesTab =
      activeTab === 'all' ||
      (activeTab === 'products' && item.type === 'Product') ||
      (activeTab === 'services' && item.type === 'Service')

    const matchesSearch =
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.category.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus =
      statusFilter === 'All' || item.status === statusFilter

    return matchesTab && matchesSearch && matchesStatus
  })

  const handleAddOffering = (event) => {
    event.preventDefault()

    const formData = new FormData(event.target)

    const newOffering = {
      id: Date.now(),
      type: offeringType,
      name: formData.get('name'),
      code: formData.get('code'),
      category: formData.get('category'),
      description: formData.get('description'),
      price: Number(formData.get('price')),
      status: formData.get('status'),
      ...(offeringType === 'Product'
        ? { billing: formData.get('billing') }
        : { duration: `${formData.get('duration')} Days` })
    }

    setOfferings((prev) => [...prev, newOffering])
    setShowModal(false)
    event.target.reset()
  }

  const handleDelete = (id) => {
    setOfferings((prev) => prev.filter((item) => item.id !== id))
    setViewItem(null)
    setEditItem(null)
  }

  return (
    <main className="products-page">
      <section className="products-header">
        <div>
          <h1>Products & Services</h1>
          <p>Manage the products and services your company offers.</p>
        </div>
        <button className="add-offering-button" onClick={() => setShowModal(true)}>
          + Add Product / Service
        </button>
      </section>

      <section className="products-toolbar">
        <div className="products-tabs">
          <button
            className={activeTab === 'all' ? 'active' : ''}
            onClick={() => setActiveTab('all')}
          >
            All
          </button>
          <button
            className={activeTab === 'products' ? 'active' : ''}
            onClick={() => setActiveTab('products')}
          >
            Products
          </button>
          <button
            className={activeTab === 'services' ? 'active' : ''}
            onClick={() => setActiveTab('services')}
          >
            Services
          </button>
        </div>

        <div className="products-filters">
          <div className="products-search">
            <span>⌕</span>
            <input
              type="text"
              placeholder="Search products or services..."
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
            />
          </div>

          <select
            value={statusFilter}
            onChange={(event) => setStatusFilter(event.target.value)}
          >
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </section>

      <section className="products-grid">
        {filteredOfferings.map((item) => (
          <div className="offering-card" key={item.id}>
            <div className="offering-card-top">
              <div className="offering-icon">
                {item.type === 'Product' ? '▣' : '◇'}
              </div>
              <span className={`offering-status ${item.status.toLowerCase()}`}>
                {item.status}
              </span>
            </div>

            <div className="offering-type">{item.type}</div>

            <h2>{item.name}</h2>

            <p className="offering-category">{item.category}</p>

            <p className="offering-description">{item.description}</p>

            <div className="offering-price">
              <strong>₹{item.price.toLocaleString('en-IN')}</strong>
              {item.type === 'Product' ? (
                <span>/ {item.billing?.toLowerCase()}</span>
              ) : (
                <span>starting price</span>
              )}
            </div>

            <div className="offering-card-footer">
              <button onClick={() => setViewItem(item)}>View</button>
              <button onClick={() => setEditItem(item)}>Edit</button>
              <button onClick={() => handleDelete(item.id)}>•••</button>
            </div>
          </div>
        ))}
      </section>

      {filteredOfferings.length === 0 && (
        <div className="empty-products">
          <h3>No products or services found</h3>
          <p>Try changing your search or filter.</p>
        </div>
      )}

      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="offering-modal" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>Add New Offering</h2>
                <p>Add a product or service to your company.</p>
              </div>
              <button onClick={() => setShowModal(false)}>×</button>
            </div>

            <div className="offering-type-selector">
              <button
                className={offeringType === 'Product' ? 'active' : ''}
                onClick={() => setOfferingType('Product')}
              >
                Product
              </button>
              <button
                className={offeringType === 'Service' ? 'active' : ''}
                onClick={() => setOfferingType('Service')}
              >
                Service
              </button>
            </div>

            <form onSubmit={handleAddOffering}>
              <div className="form-group">
                <label>{offeringType} Name *</label>
                <input name="name" type="text" placeholder={`Enter ${offeringType.toLowerCase()} name`} required />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>{offeringType} Code</label>
                  <input name="code" type="text" placeholder="CRM-PRO-001" />
                </div>

                <div className="form-group">
                  <label>Category</label>
                  <input name="category" type="text" placeholder="Enter category" />
                </div>
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea name="description" placeholder="Enter description"></textarea>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>
                    {offeringType === 'Product' ? 'Pricing' : 'Starting Price'}
                  </label>
                  <input name="price" type="number" placeholder="₹ 0" />
                </div>

                {offeringType === 'Product' ? (
                  <div className="form-group">
                    <label>Billing Type</label>
                    <select name="billing">
                      <option value="Monthly">Monthly</option>
                      <option value="Yearly">Yearly</option>
                      <option value="One-time">One-time</option>
                    </select>
                  </div>
                ) : (
                  <div className="form-group">
                    <label>Estimated Delivery</label>
                    <input name="duration" type="number" placeholder="30" />
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Status</label>
                <select name="status" defaultValue="Active">
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>

              <div className="modal-actions">
                <button type="button" onClick={() => setShowModal(false)}>
                  Cancel
                </button>
                <button type="submit">
                  Save {offeringType}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {viewItem && (
        <div className="modal-overlay" onClick={() => setViewItem(null)}>
          <div className="offering-modal detail-modal" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>{viewItem.name}</h2>
                <p>{viewItem.type} details</p>
              </div>
              <button onClick={() => setViewItem(null)}>×</button>
            </div>

            <div className="detail-list">
              <div>
                <span>Name</span>
                <strong>{viewItem.name}</strong>
              </div>
              <div>
                <span>Code</span>
                <strong>{viewItem.code || 'Not added'}</strong>
              </div>
              <div>
                <span>Category</span>
                <strong>{viewItem.category || 'Not added'}</strong>
              </div>
              <div>
                <span>Description</span>
                <strong>{viewItem.description || 'Not added'}</strong>
              </div>
              <div>
                <span>{viewItem.type === 'Product' ? 'Pricing' : 'Starting Price'}</span>
                <strong>₹{viewItem.price.toLocaleString('en-IN')}</strong>
              </div>
              <div>
                <span>{viewItem.type === 'Product' ? 'Billing Cycle' : 'Estimated Duration'}</span>
                <strong>{viewItem.type === 'Product' ? viewItem.billing : viewItem.duration}</strong>
              </div>
              <div>
                <span>Status</span>
                <strong>{viewItem.status}</strong>
              </div>
            </div>

            <div className="modal-actions">
              <button onClick={() => setViewItem(null)}>Close</button>
              <button onClick={() => {
                setViewItem(null)
                setEditItem(viewItem)
              }}>
                Edit
              </button>
            </div>
          </div>
        </div>
      )}

      {editItem && (
        <div className="modal-overlay" onClick={() => setEditItem(null)}>
          <div className="offering-modal" onClick={(event) => event.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2>Edit {editItem.type}</h2>
                <p>Update offering information.</p>
              </div>
              <button onClick={() => setEditItem(null)}>×</button>
            </div>

            <form onSubmit={(event) => {
              event.preventDefault()
              const formData = new FormData(event.target)

              setOfferings((prev) =>
                prev.map((item) =>
                  item.id === editItem.id
                    ? {
                        ...item,
                        name: formData.get('name'),
                        code: formData.get('code'),
                        category: formData.get('category'),
                        description: formData.get('description'),
                        price: Number(formData.get('price')),
                        status: formData.get('status'),
                        ...(editItem.type === 'Product'
                          ? { billing: formData.get('billing') }
                          : { duration: `${formData.get('duration')} Days` })
                      }
                    : item
                )
              )

              setEditItem(null)
            }}>
              <div className="form-group">
                <label>{editItem.type} Name *</label>
                <input name="name" defaultValue={editItem.name} required />
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>{editItem.type} Code</label>
                  <input name="code" defaultValue={editItem.code} />
                </div>

                <div className="form-group">
                  <label>Category</label>
                  <input name="category" defaultValue={editItem.category} />
                </div>
              </div>

              <div className="form-group">
                <label>Description</label>
                <textarea name="description" defaultValue={editItem.description}></textarea>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>
                    {editItem.type === 'Product' ? 'Pricing' : 'Starting Price'}
                  </label>
                  <input name="price" type="number" defaultValue={editItem.price} />
                </div>

                {editItem.type === 'Product' ? (
                  <div className="form-group">
                    <label>Billing Type</label>
                    <select name="billing" defaultValue={editItem.billing}>
                      <option value="Monthly">Monthly</option>
                      <option value="Yearly">Yearly</option>
                      <option value="One-time">One-time</option>
                    </select>
                  </div>
                ) : (
                  <div className="form-group">
                    <label>Estimated Delivery</label>
                    <input
                      name="duration"
                      type="number"
                      defaultValue={parseInt(editItem.duration)}
                    />
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>Status</label>
                <select name="status" defaultValue={editItem.status}>
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>

              <div className="modal-actions">
                <button type="button" onClick={() => setEditItem(null)}>
                  Cancel
                </button>
                <button type="submit">
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  )
}

export default Products