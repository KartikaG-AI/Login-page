import { useState } from 'react'
import './Deals.css'

function Deals() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('All')
  const [productFilter, setProductFilter] = useState('All')
  const [salesFilter, setSalesFilter] = useState('All')
  const [selectedDeal, setSelectedDeal] = useState(null)

  const deals = [
    {
      id: 1,
      name: 'AI Chatbot Platform Deal',
      customer: 'ABC Corp',
      product: 'AI Chatbot Platform',
      value: 5999,
      status: 'Won',
      assignedTo: 'Arjun',
      expectedClose: '15 Oct 2026',
      activities: ['Payment received', 'Deal closed']
    },
    {
      id: 2,
      name: 'Website Development Deal',
      customer: 'FashionHub',
      product: 'Website Development',
      value: 75000,
      status: 'Proposal',
      assignedTo: 'Jayshree',
      expectedClose: '20 Oct 2026',
      activities: ['Proposal sent', 'Requirement discussed']
    },
    {
      id: 3,
      name: 'AI Chatbot Platform Deal',
      customer: 'XYZ Ltd',
      product: 'AI Chatbot Platform',
      value: 2999,
      status: 'Negotiation',
      assignedTo: 'Anitha',
      expectedClose: '25 Oct 2026',
      activities: ['Pricing discussed', 'Demo completed']
    },
    {
      id: 4,
      name: 'Website Development Deal',
      customer: 'StyleMart',
      product: 'Website Development',
      value: 120000,
      status: 'Qualified',
      assignedTo: 'Vignesh',
      expectedClose: '30 Oct 2026',
      activities: ['Requirement collected', 'Client qualified']
    },
    {
      id: 5,
      name: 'AI Chatbot Platform Deal',
      customer: 'NextGen Systems',
      product: 'AI Chatbot Platform',
      value: 8999,
      status: 'New',
      assignedTo: 'Vignesh',
      expectedClose: '5 Nov 2026',
      activities: ['Lead converted to deal']
    },
    {
      id: 6,
      name: 'Website Development Deal',
      customer: 'TechBridge',
      product: 'Website Development',
      value: 95000,
      status: 'Lost',
      assignedTo: 'Jayshree',
      expectedClose: '10 Oct 2026',
      activities: ['Budget issue', 'Deal lost']
    }
  ]

  const filteredDeals = deals.filter((deal) => {
    const matchesSearch =
      deal.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      deal.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      deal.product.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus =
      statusFilter === 'All' || deal.status === statusFilter

    const matchesProduct =
      productFilter === 'All' || deal.product === productFilter

    const matchesSales =
      salesFilter === 'All' || deal.assignedTo === salesFilter

    return matchesSearch && matchesStatus && matchesProduct && matchesSales
  })

  const totalValue = deals.reduce(
    (total, deal) => total + deal.value,
    0
  )

  const inProgress = deals.filter(
    (deal) => !['Won', 'Lost'].includes(deal.status)
  ).length

  const wonDeals = deals.filter(
    (deal) => deal.status === 'Won'
  ).length

  return (
    <main className="deals-page">
      <section className="deals-header">
        <div>
          <h1>Deals</h1>
          <p>Manage and monitor your sales opportunities.</p>
        </div>
      </section>

      <section className="deals-summary">
        <div className="deal-summary-card">
          <span>Total Deals</span>
          <strong>{deals.length}</strong>
        </div>

        <div className="deal-summary-card">
          <span>In Progress</span>
          <strong>{inProgress}</strong>
        </div>

        <div className="deal-summary-card">
          <span>Won</span>
          <strong>{wonDeals}</strong>
        </div>

        <div className="deal-summary-card">
          <span>Total Value</span>
          <strong>₹{(totalValue / 100000).toFixed(1)}L</strong>
        </div>
      </section>

      <section className="deals-table-card">
        <div className="deals-toolbar">
          <div className="deal-search">
            <span>⌕</span>

            <input
              type="text"
              placeholder="Search deals..."
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
            />
          </div>

          <div className="deal-filters">
            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
            >
              <option value="All">All Status</option>
              <option value="New">New</option>
              <option value="Qualified">Qualified</option>
              <option value="Proposal">Proposal</option>
              <option value="Negotiation">Negotiation</option>
              <option value="Won">Won</option>
              <option value="Lost">Lost</option>
            </select>

            <select
              value={productFilter}
              onChange={(event) => setProductFilter(event.target.value)}
            >
              <option value="All">All Products</option>
              <option value="AI Chatbot Platform">AI Chatbot Platform</option>
              <option value="Website Development">Website Development</option>
            </select>

            <select
              value={salesFilter}
              onChange={(event) => setSalesFilter(event.target.value)}
            >
              <option value="All">All Sales Users</option>
              <option value="Arjun">Arjun</option>
              <option value="Jayshree">Jayshree</option>
              <option value="Anitha">Anitha</option>
              <option value="Vignesh">Vignesh</option>
            </select>
          </div>
        </div>

        <div className="deals-table-wrapper">
          <table className="deals-table">
            <thead>
              <tr>
                <th>DEAL NAME</th>
                <th>CUSTOMER</th>
                <th>PRODUCT / SERVICE</th>
                <th>VALUE</th>
                <th>STATUS</th>
                <th>ASSIGNED TO</th>
                <th>EXPECTED CLOSE</th>
              </tr>
            </thead>

            <tbody>
              {filteredDeals.map((deal) => (
                <tr
                  key={deal.id}
                  onClick={() => setSelectedDeal(deal)}
                >
                  <td>
                    <div className="deal-name-cell">
                      <div className="deal-avatar">
                        {deal.name
                          .split(' ')
                          .map((word) => word[0])
                          .join('')
                          .slice(0, 2)}
                      </div>

                      <strong>{deal.name}</strong>
                    </div>
                  </td>

                  <td>{deal.customer}</td>

                  <td>{deal.product}</td>

                  <td className="deal-value">
                    ₹{deal.value.toLocaleString('en-IN')}
                  </td>

                  <td>
                    <span
                      className={`deal-status ${deal.status.toLowerCase()}`}
                    >
                      {deal.status}
                    </span>
                  </td>

                  <td>
                    <div className="assigned-user">
                      <div className="assigned-avatar">
                        {deal.assignedTo[0]}
                      </div>

                      <span>{deal.assignedTo}</span>
                    </div>
                  </td>

                  <td>{deal.expectedClose}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredDeals.length === 0 && (
          <div className="no-deals">
            <h3>No deals found</h3>
            <p>Try changing your search or filters.</p>
          </div>
        )}
      </section>

      {selectedDeal && (
        <div
          className="deal-panel-overlay"
          onClick={() => setSelectedDeal(null)}
        >
          <aside
            className="deal-details-panel"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="deal-panel-header">
              <div>
                <span>Deal Details</span>
                <h2>{selectedDeal.name}</h2>
              </div>

              <button onClick={() => setSelectedDeal(null)}>
                ×
              </button>
            </div>

            <div className="deal-panel-content">
              <div className="deal-detail-item">
                <span>Customer</span>
                <strong>{selectedDeal.customer}</strong>
              </div>

              <div className="deal-detail-item">
                <span>Product / Service</span>
                <strong>{selectedDeal.product}</strong>
              </div>

              <div className="deal-detail-item">
                <span>Deal Value</span>
                <strong>
                  ₹{selectedDeal.value.toLocaleString('en-IN')}
                </strong>
              </div>

              <div className="deal-detail-item">
                <span>Status</span>

                <span
                  className={`deal-status ${selectedDeal.status.toLowerCase()}`}
                >
                  {selectedDeal.status}
                </span>
              </div>

              <div className="deal-detail-item">
                <span>Assigned To</span>
                <strong>{selectedDeal.assignedTo}</strong>
              </div>

              <div className="deal-detail-item">
                <span>Expected Close</span>
                <strong>{selectedDeal.expectedClose}</strong>
              </div>

              <div className="activity-section">
                <h3>Recent Activity</h3>

                {selectedDeal.activities.map((activity, index) => (
                  <div className="activity-item" key={index}>
                    <span className="activity-dot"></span>
                    <span>{activity}</span>
                  </div>
                ))}
              </div>

              <button className="edit-deal-button">
                Edit Deal
              </button>
            </div>
          </aside>
        </div>
      )}
    </main>
  )
}

export default Deals