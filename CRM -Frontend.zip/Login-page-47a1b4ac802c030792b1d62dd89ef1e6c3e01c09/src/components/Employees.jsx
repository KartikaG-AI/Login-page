import { useState } from 'react'
import './Employees.css'

function Employees() {
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState('All')
  const [selectedEmployee, setSelectedEmployee] = useState(null)

  const employees = [
    {
      id: 1,
      name: 'Anitha',
      email: 'anitha@devhub.com',
      role: 'Sales Executive',
      status: 'Active',
      deals: 24,
      won: 15,
      revenue: 840000,
      tasks: 42,
      activeDeals: 9,
      leadsAssigned: 48,
      qualified: 32,
      calls: 35,
      meetings: 12,
      demos: 8,
      followUps: 28,
      lost: 6,
      inProgress: 3
    },
    {
      id: 2,
      name: 'Arjun',
      email: 'arju@devhub.com',
      role: 'Sales Executive',
      status: 'Active',
      deals: 31,
      won: 19,
      revenue: 1020000,
      tasks: 56,
      activeDeals: 11,
      leadsAssigned: 55,
      qualified: 38,
      calls: 42,
      meetings: 15,
      demos: 10,
      followUps: 35,
      lost: 8,
      inProgress: 4
    },
    {
      id: 3,
      name: 'Vignesh',
      email: 'vignesh@devhub.com',
      role: 'Sales Executive',
      status: 'Active',
      deals: 22,
      won: 13,
      revenue: 720000,
      tasks: 47,
      activeDeals: 7,
      leadsAssigned: 44,
      qualified: 29,
      calls: 31,
      meetings: 11,
      demos: 7,
      followUps: 25,
      lost: 5,
      inProgress: 4
    },
    {
      id: 4,
      name: 'Jaysree',
      email: 'jaysree@devhub.com',
      role: 'Sales Executive',
      status: 'Active',
      deals: 18,
      won: 9,
      revenue: 570000,
      tasks: 37,
      activeDeals: 6,
      leadsAssigned: 36,
      qualified: 24,
      calls: 29,
      meetings: 9,
      demos: 6,
      followUps: 21,
      lost: 6,
      inProgress: 3
    }
  ]

  const filteredEmployees = employees.filter((employee) => {
    const matchesSearch =
      employee.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      employee.email.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesStatus =
      statusFilter === 'All' || employee.status === statusFilter

    return matchesSearch && matchesStatus
  })

  const activeUsers = employees.filter(
    (employee) => employee.status === 'Active'
  ).length

  return (
    <main className="employees-page">
      <section className="employees-header">
        <div>
          <h1>Employees</h1>
          <p>Manage sales executives and monitor their performance.</p>
        </div>
        <button className="add-employee-button">+ Add Employee</button>
      </section>

      <section className="employees-summary">
        <div className="employee-summary-card">
          <span>Total Users</span>
          <strong>{employees.length}</strong>
        </div>

        <div className="employee-summary-card">
          <span>Active Users</span>
          <strong>{activeUsers}</strong>
        </div>

        <div className="employee-summary-card">
          <span>Seats Used</span>
          <strong>{employees.length} / 15</strong>
        </div>
      </section>

      <section className="employees-table-card">
        <div className="employees-toolbar">
          <div className="employee-search">
            <span>⌕</span>
            <input
              type="text"
              placeholder="Search employee..."
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
            />
          </div>

          <div className="employee-filters">
            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value)}
            >
              <option value="All">All Status</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>
        </div>

        <div className="employees-table-wrapper">
          <table className="employees-table">
            <thead>
              <tr>
                <th>EMPLOYEE</th>
                <th>ROLE</th>
                <th>DEALS</th>
                <th>WON</th>
                <th>REVENUE</th>
                <th>TASKS</th>
                <th>STATUS</th>
              </tr>
            </thead>

            <tbody>
              {filteredEmployees.map((employee) => (
                <tr
                  key={employee.id}
                  onClick={() => setSelectedEmployee(employee)}
                >
                  <td>
                    <div className="employee-name-cell">
                      <div className="employee-avatar">
                        {employee.name
                          .split(' ')
                          .map((word) => word[0])
                          .join('')
                          .slice(0, 2)
                          .toUpperCase()}
                      </div>

                      <div>
                        <strong>{employee.name}</strong>
                        <span>{employee.email}</span>
                      </div>
                    </div>
                  </td>

                  <td>
                    <span className="employee-role">
                      {employee.role}
                    </span>
                  </td>

                  <td>{employee.deals}</td>

                  <td>{employee.won}</td>

                  <td className="employee-revenue">
                    ₹{(employee.revenue / 100000).toFixed(1)}L
                  </td>

                  <td>{employee.tasks}</td>

                  <td>
                    <span
                      className={`employee-status ${employee.status.toLowerCase()}`}
                    >
                      {employee.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredEmployees.length === 0 && (
          <div className="no-employees">
            <h3>No employees found</h3>
            <p>Try changing your search or filter.</p>
          </div>
        )}
      </section>

      {selectedEmployee && (
        <div
          className="employee-panel-overlay"
          onClick={() => setSelectedEmployee(null)}
        >
          <aside
            className="employee-details-panel"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="employee-panel-header">
              <div className="employee-profile">
                <div className="large-employee-avatar">
                  {selectedEmployee.name
                    .split(' ')
                    .map((word) => word[0])
                    .join('')
                    .slice(0, 2)
                    .toUpperCase()}
                </div>

                <div>
                  <h2>{selectedEmployee.name}</h2>
                  <p>{selectedEmployee.role}</p>
                  <span>● {selectedEmployee.status}</span>
                </div>
              </div>

              <button onClick={() => setSelectedEmployee(null)}>
                ×
              </button>
            </div>

            <div className="employee-panel-email">
              {selectedEmployee.email}
            </div>

            <div className="employee-panel-actions">
              <button>Edit</button>
              <button>Deactivate</button>
            </div>

            <section className="performance-section">
              <h3>Performance Overview</h3>

              <div className="performance-grid">
                <div>
                  <span>Total Deals</span>
                  <strong>{selectedEmployee.deals}</strong>
                </div>

                <div>
                  <span>Deals Won</span>
                  <strong>{selectedEmployee.won}</strong>
                </div>

                <div>
                  <span>Revenue</span>
                  <strong>
                    ₹{(selectedEmployee.revenue / 100000).toFixed(1)}L
                  </strong>
                </div>

                <div>
                  <span>Win Rate</span>
                  <strong>
                    {(
                      (selectedEmployee.won /
                        selectedEmployee.deals) *
                      100
                    ).toFixed(1)}
                    %
                  </strong>
                </div>

                <div>
                  <span>Active Deals</span>
                  <strong>{selectedEmployee.activeDeals}</strong>
                </div>

                <div>
                  <span>Tasks Done</span>
                  <strong>{selectedEmployee.tasks}</strong>
                </div>
              </div>
            </section>

            <section className="employee-detail-section">
              <h3>Deal Performance</h3>

              <div className="deal-performance-row">
                <span>Won</span>
                <strong>{selectedEmployee.won}</strong>
              </div>

              <div className="performance-bar">
                <span
                  style={{
                    width: `${(selectedEmployee.won / selectedEmployee.deals) * 100}%`
                  }}
                ></span>
              </div>

              <div className="deal-performance-row">
                <span>Lost</span>
                <strong>{selectedEmployee.lost}</strong>
              </div>

              <div className="performance-bar lost-bar">
                <span
                  style={{
                    width: `${(selectedEmployee.lost / selectedEmployee.deals) * 100}%`
                  }}
                ></span>
              </div>

              <div className="deal-performance-row">
                <span>In Progress</span>
                <strong>{selectedEmployee.inProgress}</strong>
              </div>

              <div className="performance-bar progress-bar">
                <span
                  style={{
                    width: `${(selectedEmployee.inProgress / selectedEmployee.deals) * 100}%`
                  }}
                ></span>
              </div>
            </section>

            <section className="employee-detail-section">
              <h3>Revenue Performance</h3>

              <div className="revenue-row">
                <span>This Month</span>
                <strong>₹2.4L</strong>
              </div>

              <div className="revenue-row">
                <span>This Quarter</span>
                <strong>
                  ₹{(selectedEmployee.revenue / 100000).toFixed(1)}L
                </strong>
              </div>

              <div className="revenue-row">
                <span>Total</span>
                <strong>
                  ₹{(selectedEmployee.revenue / 100000).toFixed(1)}L
                </strong>
              </div>
            </section>

            <section className="employee-detail-section">
              <h3>Sales Performance</h3>

              <div className="sales-metric-row">
                <span>Leads Assigned</span>
                <strong>{selectedEmployee.leadsAssigned}</strong>
              </div>

              <div className="sales-metric-row">
                <span>Qualified</span>
                <strong>{selectedEmployee.qualified}</strong>
              </div>

              <div className="sales-metric-row">
                <span>Deals Created</span>
                <strong>{selectedEmployee.deals}</strong>
              </div>

              <div className="sales-metric-row">
                <span>Deals Won</span>
                <strong>{selectedEmployee.won}</strong>
              </div>

              <div className="sales-metric-row">
                <span>Win Rate</span>
                <strong>
                  {(
                    (selectedEmployee.won /
                      selectedEmployee.deals) *
                    100
                  ).toFixed(1)}
                  %
                </strong>
              </div>
            </section>

            <section className="employee-detail-section">
              <h3>Activities</h3>

              <div className="activity-grid">
                <div>
                  <span>Calls</span>
                  <strong>{selectedEmployee.calls}</strong>
                </div>

                <div>
                  <span>Meetings</span>
                  <strong>{selectedEmployee.meetings}</strong>
                </div>

                <div>
                  <span>Demos</span>
                  <strong>{selectedEmployee.demos}</strong>
                </div>

                <div>
                  <span>Follow-ups</span>
                  <strong>{selectedEmployee.followUps}</strong>
                </div>

                <div>
                  <span>Tasks Completed</span>
                  <strong>{selectedEmployee.tasks}</strong>
                </div>
              </div>
            </section>
          </aside>
        </div>
      )}
    </main>
  )
}

export default Employees