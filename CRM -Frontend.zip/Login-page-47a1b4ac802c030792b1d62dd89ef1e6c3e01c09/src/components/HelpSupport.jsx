import './HelpSupport.css'

function HelpSupport() {
  return (
    <main className="help-page">
      <section className="help-header">
        <div>
          <h1>Help & Support</h1>
          <p>Get help with Cliently and manage your support requests.</p>
        </div>
      </section>

      <section className="help-search-card">
        <div className="help-search-icon">⌕</div>
        <div>
          <h2>How can we help?</h2>
          <p>Search Cliently guides, features and troubleshooting articles.</p>
        </div>
        <input
          type="text"
          placeholder="Search help articles..."
        />
      </section>

      <section className="help-grid">
        <div className="help-card">
          <div className="help-card-icon">?</div>
          <h2>Help Center</h2>
          <p>Find answers and learn how to use Cliently CRM.</p>
          <button>Browse Help Center →</button>
        </div>

        <div className="help-card">
          <div className="help-card-icon">✉</div>
          <h2>Contact Support</h2>
          <p>Need assistance? Send a request to the Cliently support team.</p>
          <button>Contact Support →</button>
        </div>

        <div className="help-card">
          <div className="help-card-icon">✓</div>
          <h2>My Tickets</h2>
          <p>View and track your support requests submitted to Cliently.</p>
          <button>View Tickets →</button>
        </div>
      </section>

      <section className="help-bottom-grid">
        <div className="help-section-card">
          <div className="help-section-header">
            <div>
              <h2>Quick Guides</h2>
              <p>Learn the basics of Cliently CRM.</p>
            </div>
          </div>

          <div className="guide-list">
            <div className="guide-item">
              <div className="guide-icon">◉</div>
              <div>
                <strong>Managing Leads</strong>
                <span>Add, assign and track your leads.</span>
              </div>
              <span className="guide-arrow">→</span>
            </div>

            <div className="guide-item">
              <div className="guide-icon">◇</div>
              <div>
                <strong>Managing Deals</strong>
                <span>Track opportunities and sales progress.</span>
              </div>
              <span className="guide-arrow">→</span>
            </div>

            <div className="guide-item">
              <div className="guide-icon">▣</div>
              <div>
                <strong>Analytics</strong>
                <span>Understand your company's sales performance.</span>
              </div>
              <span className="guide-arrow">→</span>
            </div>

            <div className="guide-item">
              <div className="guide-icon">⚙</div>
              <div>
                <strong>Settings</strong>
                <span>Manage company, users and billing settings.</span>
              </div>
              <span className="guide-arrow">→</span>
            </div>
          </div>
        </div>

        <div className="help-section-card">
          <div className="help-section-header">
            <div>
              <h2>System Status</h2>
              <p>Current Cliently platform status.</p>
            </div>

            <span className="system-status-badge">
              All Systems Operational
            </span>
          </div>

          <div className="system-status-list">
            <div className="system-status-item">
              <span>Cliently CRM</span>
              <strong>Operational</strong>
            </div>

            <div className="system-status-item">
              <span>API Services</span>
              <strong>Operational</strong>
            </div>

            <div className="system-status-item">
              <span>Database</span>
              <strong>Operational</strong>
            </div>

            <div className="system-status-item">
              <span>Notifications</span>
              <strong>Operational</strong>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

export default HelpSupport