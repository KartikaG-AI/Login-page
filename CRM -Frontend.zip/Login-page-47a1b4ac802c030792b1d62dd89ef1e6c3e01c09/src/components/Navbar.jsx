export default function Navbar() {
  return (
    <header className="navbar">
      <div className="container nav-inner">
        
        <a href="#" className="logo">
          <span className="logo-mark">C</span>
          Cliently
        </a>

        <nav className="nav-links">
          <a href="#features">Features</a>
          <a href="#how">How It Works</a>
          <a href="#solutions">Reviews</a>
          <a href="#pricing">Pricing</a>
          <a href="#faq">FAQ</a>
        </nav>

        <div className="nav-actions">
          <a href="#" className="link-login">
            Login
          </a>

          <a href="#pricing" className="btn">
            Get Started
          </a>
        </div>

      </div>
    </header>
  );
}