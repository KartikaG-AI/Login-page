import './Leads.css'
function Leads() {
  const leads = [
    { id: 1, name: 'ArunBalaji', email: 'arun@gmail.com', company: 'Tech Solutions', phone: '+91 9876543210', status: 'Qualified', value: 250000, source: 'AI Chatbot Platform', executive: 'Arjun' },
    { id: 2, name: 'Mounika M', email: 'mouni@gmail.com', company: 'BlueWave Pvt Ltd', phone: '+91 9876543211', status: 'New', value: 180000, source: 'AI Chatbot Platform', executive: 'Anitha' },
    { id: 3, name: 'Jeya Kartika G', email: 'jeykagovinda@gmail.com', company: 'NextGen Systems', phone: '+91 9876543212', status: 'Contacted', value: 320000, source: 'Website', executive: 'Vignesh' },
    { id: 4, name: 'Geethavarshini R', email: 'geethu@gmail.com', company: 'CloudBridge', phone: '+91 9876543213', status: 'Proposal', value: 450000, source: 'AI Chatbot Platform', executive: 'Arjun' },
    { id: 5, name: 'Joshua Jenisus R', email: 'jenisusjr07@gmail.com', company: 'Vertex Labs', phone: '+91 9876543214', status: 'Qualified', value: 210000, source: 'Website', executive: 'Anitha' },
    { id: 6, name: 'Gocegin Sanjay N', email: 'goce@gmail.com', company: 'Embedded Pvt Ltd', phone: '+91 9876543215', status: 'New', value: 180000, source: 'AI Chatbot Platform', executive: 'Vignesh' },
    { id: 7, name: 'Kiruthika K', email: 'kiki@gmail.com', company: 'Photonic Solutions', phone: '+91 9876543216', status: 'Proposal', value: 300000, source: 'Website', executive: 'Arjun' },
    { id: 8, name: 'Krishnaji S', email: 'krishna@gmail.com', company: 'Techlead Solutions', phone: '+91 9876543217', status: 'Contacted', value: 80000, source: 'Website', executive: 'Anitha' }
  ]
  return (
    <main className="leads-page">
      <section className="leads-page-header">
        <div>
          <h1>Leads</h1>
          <p>Manage and track all your leads</p>
        </div>
      </section>
      <section className="leads-summary">
        <div className="lead-summary-card">
          <span>Total Leads</span>
          <strong>{leads.length}</strong>
        </div>
        <div className="lead-summary-card">
          <span>New</span>
          <strong>{leads.filter((lead) => lead.status === 'New').length}</strong>
        </div>
        <div className="lead-summary-card">
          <span>Qualified</span>
          <strong>{leads.filter((lead) => lead.status === 'Qualified').length}</strong>
        </div>
        <div className="lead-summary-card">
          <span>Assigned Executives</span>
          <strong>{new Set(leads.map((lead) => lead.executive)).size}</strong>
        </div>
      </section>
      <section className="leads-table-card">
        <div className="leads-table-header">
          <div>
            <h2>All Leads</h2>
            <p>Complete lead information and assigned sales executives</p>
          </div>
        </div>
        <div className="leads-table-wrapper">
          <table className="leads-table">
            <thead>
              <tr>
                <th>LEAD</th>
                <th>COMPANY</th>
                <th>CONTACT</th>
                <th>STATUS</th>
                <th>VALUE</th>
                <th>PRODUCT ENQUIRED</th>
                <th>SALES EXECUTIVE</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id}>
                  <td>
                    <div className="lead-name-cell">
                      <div className="lead-table-avatar">
                        {lead.name.split(' ').map((word) => word[0]).join('').slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <strong>{lead.name}</strong>
                        <span>{lead.email}</span>
                      </div>
                    </div>
                  </td>
                  <td>{lead.company}</td>
                  <td>{lead.phone}</td>
                  <td>
                    <span className={`lead-page-status ${lead.status.toLowerCase()}`}>
                      {lead.status}
                    </span>
                  </td>
                  <td className="lead-page-value">₹{(lead.value / 100000).toFixed(1)}L</td>
                  <td>{lead.source}</td>
                  <td>
                    <div className="executive-cell">
                      <div className="executive-avatar">
                        {lead.executive.split(' ').map((word) => word[0]).join('').slice(0, 2).toUpperCase()}
                      </div>
                      <span>{lead.executive}</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  )
}
export default Leads