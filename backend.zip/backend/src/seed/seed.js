
require('dotenv').config()

const mongoose = require('mongoose')
const connectDB = require('../config/db')
const Tenant = require('../models/Tenant')
const Lead = require('../models/Lead')
const Deal = require('../models/Deal')
const Employee = require('../models/Employee')
const Product = require('../models/Product')
const Invoice = require('../models/Invoice')
const data = require('./data')

async function seed() {
  await connectDB()
  await Promise.all([Employee.init(), Product.init(), Invoice.init()])

  const tenant = await Tenant.findOneAndUpdate(
    { slug: data.tenant.slug },
    data.tenant,
    { upsert: true, returnDocument: 'after' }
  )
  console.log(`Tenant ready: ${tenant.companyName} (${tenant._id})`)

  const ownData = { tenantId: tenant._id }
  const [oldLeads, oldDeals, oldEmployees, oldProducts, oldInvoices] = await Promise.all([
    Lead.deleteMany(ownData),
    Deal.deleteMany(ownData),
    Employee.deleteMany(ownData),
    Product.deleteMany(ownData),
    Invoice.deleteMany(ownData)
  ])
  console.log(
    `Removed old data: ${oldLeads.deletedCount} leads, ${oldDeals.deletedCount} deals, ` +
    `${oldEmployees.deletedCount} employees, ${oldProducts.deletedCount} products, ${oldInvoices.deletedCount} invoices`
  )

  const now = Date.now()
  const leads = data.leads.map(({ minutesAgo, ...lead }) => {
    const createdAt = new Date(now - minutesAgo * 60 * 1000)
    return { ...lead, tenantId: tenant._id, createdAt, updatedAt: createdAt }
  })
  await Lead.insertMany(leads, { timestamps: false })

  const deals = data.deals.map((deal) => ({ ...deal, tenantId: tenant._id }))
  await Deal.insertMany(deals)

  const employees = data.employees.map((employee) => ({ ...employee, tenantId: tenant._id }))
  await Employee.insertMany(employees)

  const products = (data.products || []).map((product) => ({ ...product, tenantId: tenant._id }))
  await Product.insertMany(products)

  const invoices = data.invoices.map((invoice) => ({ ...invoice, tenantId: tenant._id }))
  await Invoice.insertMany(invoices)

  console.log(
    `Inserted ${leads.length} leads, ${deals.length} deals, ${employees.length} employees, ` +
    `${products.length} products and ${invoices.length} invoices`
  )
}

seed()
  .catch((err) => {
    console.error('Seed failed:', err.message)
    process.exitCode = 1
  })
  .finally(() => mongoose.disconnect())