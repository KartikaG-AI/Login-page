import './Dashboard.css'

function Dashboard() {
  const stats = {
    totalLeads: 24,
    qualifiedLeads: 12,
    openDeals: 8,
    totalRevenue: 1970000
  }

  const recentLeads = [
    {
      id: 1,
      name: 'Krishnaji S',
      email: 'krish@gmail.com',
      status: 'Contacted',
      value: 80000
    },
    {
      id: 2,
      name: 'Geethavarshini R',
      email: 'geethu@gmail.com',
      status: 'Proposal',
      value: 450000
    },
    {
      id: 3,
      name: 'Joshua Jenisus R',
      email: 'jenisusr07@gmail.com',
      status: 'Qualified',
      value: 210000
    },
    {
      id: 4,
      name: 'Mounika M',
      email: 'mouni@gmail.com',
      status: 'New',
      value: 180000
    },
    {
      id: 5,
      name: 'ArunBalaji',
      email: 'arun@gmail.com',
      status: 'Qualified',
      value: 250000
    }
  ]

  const leadsByStatus = {
    New: 6,
    Contacted: 8,
    Qualified: 7,
    Proposal: 3
  }

  return (
    <main className="dashboard">
      <section className="dashboard-header">
        <div className="dashboard-header-left">
          <h1>Hi, Jeyka</h1>
          <p>Here's what's happening at DevHub today</p>
        </div>
        <div className="dashboard-header-right">
          <button className="month-button">
            This Month
          </button>
        </div>
      </section>

      <section className="sum-cards">
        <div className="sum-card">
          <div className="sum-card-top">
            <div className="sum-icon">♧</div>
            <button className="card-menu">⋯</button>
          </div>
          <p className="sum-label">Total Leads</p>
          <h2 className="sum-value">{stats.totalLeads}</h2>
        </div>

        <div className="sum-card">
          <div className="sum-card-top">
            <div className="sum-icon">♧</div>
            <button className="card-menu">⋯</button>
          </div>
          <p className="sum-label">Qualified Leads</p>
          <h2 className="sum-value">{stats.qualifiedLeads}</h2>
        </div>

        <div className="sum-card">
          <div className="sum-card-top">
            <div className="sum-icon">▣</div>
            <button className="card-menu">⋯</button>
          </div>
          <p className="sum-label">Open Deals</p>
          <h2 className="sum-value">{stats.openDeals}</h2>
        </div>

        <div className="sum-card">
          <div className="sum-card-top">
            <div className="sum-icon">₹</div>
            <button className="card-menu">⋯</button>
          </div>
          <p className="sum-label">Total Revenue</p>
          <h2 className="sum-value">
            ₹{stats.totalRevenue.toLocaleString('en-IN')}
          </h2>
        </div>
      </section>

      <section className="leads-section">
        <div className="recent-leads-card">
          <div className="section-header">
            <div>
              <h2>Recent Leads</h2>
              <p>Latest leads added to DevHub CRM</p>
            </div>
            <button className="view-all-button">
              View all ↗
            </button>
          </div>

          <div className="recent-leads-list">
            {recentLeads.map((lead) => (
              <div className="lead-row" key={lead.id}>
                <div className="lead-person">
                  <div className="lead-avatar">
                    {lead.name
                      .split(' ')
                      .map((word) => word[0])
                      .join('')
                      .slice(0, 2)
                      .toUpperCase()}
                  </div>

                  <div className="lead-info">
                    <strong>{lead.name}</strong>
                    <span>{lead.email}</span>
                  </div>
                </div>

                <div className={`lead-status ${lead.status.toLowerCase()}`}>
                  {lead.status}
                </div>

                <div className="lead-value">
                  ₹{(lead.value / 100000).toFixed(1)}L
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="status-card">
          <div className="section-header">
            <div>
              <h2>Leads by Status</h2>
              <p>Current lead distribution</p>
            </div>
            <button className="card-menu">
              ⋯
            </button>
          </div>

          <div className="status-content">
            <div className="status-chart">
              <div className="status-chart-center">
                <strong>{stats.totalLeads}</strong>
                <span>Total Leads</span>
              </div>
            </div>

            <div className="status-list">
              <div className="status-item">
                <span className="status-dot new-dot"></span>
                <span>New</span>
                <strong>{leadsByStatus.New}</strong>
              </div>

              <div className="status-item">
                <span className="status-dot contacted-dot"></span>
                <span>Contacted</span>
                <strong>{leadsByStatus.Contacted}</strong>
              </div>

              <div className="status-item">
                <span className="status-dot qualified-dot"></span>
                <span>Qualified</span>
                <strong>{leadsByStatus.Qualified}</strong>
              </div>

              <div className="status-item">
                <span className="status-dot proposal-dot"></span>
                <span>Proposal</span>
                <strong>{leadsByStatus.Proposal}</strong>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}

export default Dashboard