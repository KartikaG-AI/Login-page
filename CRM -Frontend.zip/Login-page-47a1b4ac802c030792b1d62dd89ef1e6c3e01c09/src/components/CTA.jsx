export default function CTA() {
  return (
    <section className="cta-wrap">
      <div className="container">
        <div className="cta-box">
          <div>
            <h2> CRM?</h2>

            <p>
              Bring your customers, sales pipeline and business activities
              together in one powerful platform.
            </p>
          </div>

          <a href="#pricing" className="btn btn-cream btn-lg">
            Get Started
          </a>
        </div>
      </div>
    </section>
  );
}