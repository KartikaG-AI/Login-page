import { useState } from 'react'
import './Settings.css'

function Settings() {
  const [activeSection, setActiveSection] = useState('company')

  const users = [
    {
      id: 1,
      name: 'Anitha',
      email: 'anitha@cliently.com',
      role: 'Sales Executive',
      status: 'Active'
    },
    {
      id: 2,
      name: 'Arjun',
      email: 'arjun@cliently.com',
      role: 'Sales Executive',
      status: 'Active'
    },
    {
      id: 3,
      name: 'Vignesh',
      email: 'Vignesh@cliently.com',
      role: 'Sales Executive',
      status: 'Active'
    },
    {
      id: 4,
      name: 'Jayashree',
      email: 'jaysree@cliently.com',
      role: 'Sales Executive',
      status: 'Inactive'
    }
  ]

  const billingHistory = [
    {
      id: 1,
      date: '01 Oct 2026',
      amount: '₹2,999',
      status: 'Paid'
    },
    {
      id: 2,
      date: '01 Sep 2026',
      amount: '₹2,999',
      status: 'Paid'
    },
    {
      id: 3,
      date: '01 Aug 2026',
      amount: '₹2,999',
      status: 'Paid'
    }
  ]

  return (
    <main className="settings-page">
      <section className="settings-header">
        <div>
          <h1>Settings</h1>
          <p>Manage your company, CRM and account settings</p>
        </div>
      </section>

      <section className="settings-layout">
        <div className="settings-menu">
          <button
            className={`settings-menu-item ${activeSection === 'company' ? 'active' : ''}`}
            onClick={() => setActiveSection('company')}
          >
            <div>
              <strong>Company Profile</strong>
              <span>Company information</span>
            </div>
          </button>

          <button
            className={`settings-menu-item ${activeSection === 'users' ? 'active' : ''}`}
            onClick={() => setActiveSection('users')}
          >
            <div>
              <strong>Users & Permissions</strong>
              <span>Manage users and access</span>
            </div>
          </button>

          <button
            className={`settings-menu-item ${activeSection === 'billing' ? 'active' : ''}`}
            onClick={() => setActiveSection('billing')}
          >
            <div>
              <strong>Subscription & Billing</strong>
              <span>Manage your plan and billing</span>
            </div>
          </button>
        </div>

        <div className="settings-content">

          {activeSection === 'company' && (
            <div className="settings-card">
              <div className="settings-card-header">
                <div>
                  <h2>Company Profile</h2>
                  <p>Manage your company information</p>
                </div>

                <button className="settings-save-button">
                  Save Changes
                </button>
              </div>

              <div className="company-logo-section">
                <div className="company-logo">C</div>

                <div>
                  <strong>Company Logo</strong>
                  <p>Upload your company logo</p>

                  <button className="upload-logo-button">
                    Upload Logo
                  </button>
                </div>
              </div>

              <div className="settings-form">
                <div className="settings-form-group">
                  <label>Company Name</label>
                  <input
                    type="text"
                    placeholder="Enter company name"
                  />
                </div>

                <div className="settings-form-row">
                  <div className="settings-form-group">
                    <label>Email</label>
                    <input
                      type="email"
                      placeholder="company@example.com"
                    />
                  </div>

                  <div className="settings-form-group">
                    <label>Phone</label>
                    <input
                      type="text"
                      placeholder="+91 9876543210"
                    />
                  </div>
                </div>

                <div className="settings-form-group">
                  <label>Website</label>
                  <input
                    type="text"
                    placeholder="https://www.example.com"
                  />
                </div>

                <div className="settings-form-group">
                  <label>Industry</label>

                  <select>
                    <option value="">Select industry</option>
                    <option value="software">
                      Software & Technology
                    </option>
                    <option value="consulting">
                      Consulting
                    </option>
                    <option value="finance">
                      Finance
                    </option>
                    <option value="healthcare">
                      Healthcare
                    </option>
                    <option value="education">
                      Education
                    </option>
                    <option value="retail">
                      Retail
                    </option>
                    <option value="other">
                      Other
                    </option>
                  </select>
                </div>

                <div className="settings-form-group">
                  <label>Address</label>

                  <textarea
                    placeholder="Enter company address"
                  ></textarea>
                </div>
              </div>
            </div>
          )}

          {activeSection === 'users' && (
            <div className="settings-card">
              <div className="settings-card-header">
                <div>
                  <h2>Users & Permissions</h2>
                  <p>Manage users, roles and access</p>
                </div>

                <button className="settings-save-button">
                  + Add User
                </button>
              </div>

              <div className="users-summary">
                <div>
                  <span>Total Users</span>
                  <strong>{users.length}</strong>
                </div>

                <div>
                  <span>Active Users</span>

                  <strong>
                    {users.filter(
                      (user) => user.status === 'Active'
                    ).length}
                  </strong>
                </div>

                <div>
                  <span>Inactive Users</span>

                  <strong>
                    {users.filter(
                      (user) => user.status === 'Inactive'
                    ).length}
                  </strong>
                </div>
              </div>

              <div className="users-table-wrapper">
                <table className="users-table">
                  <thead>
                    <tr>
                      <th>USER</th>
                      <th>ROLE</th>
                      <th>STATUS</th>
                      <th>ACTION</th>
                    </tr>
                  </thead>

                  <tbody>
                    {users.map((user) => (
                      <tr key={user.id}>
                        <td>
                          <div className="settings-user">
                            <div className="settings-user-avatar">
                              {user.name
                                .split(' ')
                                .map((word) => word[0])
                                .join('')
                                .slice(0, 2)
                                .toUpperCase()}
                            </div>

                            <div>
                              <strong>{user.name}</strong>
                              <span>{user.email}</span>
                            </div>
                          </div>
                        </td>

                        <td>
                          <span className="user-role">
                            {user.role}
                          </span>
                        </td>

                        <td>
                          <span
                            className={`user-status ${user.status.toLowerCase()}`}
                          >
                            {user.status}
                          </span>
                        </td>

                        <td>
                          <button className="user-action-button">
                            Edit
                          </button>

                          <button className="user-action-button">
                            {user.status === 'Active'
                              ? 'Deactivate'
                              : 'Activate'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeSection === 'billing' && (
            <div className="settings-card">
              <div className="settings-card-header">
                <div>
                  <h2>Subscription & Billing</h2>
                  <p>Manage your plan, payment and billing history</p>
                </div>

                <button className="settings-save-button">
                  Upgrade Plan
                </button>
              </div>

              <div className="billing-content">

                <div className="current-plan">
                  <div>
                    <span className="billing-label">
                      CURRENT PLAN
                    </span>

                    <h3>Professional</h3>

                    <p>
                      Suitable for growing sales teams
                    </p>
                  </div>

                  <div className="plan-price">
                    <strong>₹2,999</strong>
                    <span>/ month</span>
                  </div>
                </div>

                <div className="billing-summary">
                  <div className="billing-summary-card">
                    <span>Seats Used</span>
                    <strong>4 / 15</strong>
                  </div>

                  <div className="billing-summary-card">
                    <span>Available Seats</span>
                    <strong>11</strong>
                  </div>

                  <div className="billing-summary-card">
                    <span>Next Billing Date</span>
                    <strong>01 Nov 2026</strong>
                  </div>
                </div>

                <div className="billing-section">
                  <div className="billing-section-header">
                    <div>
                      <h3>Payment Method</h3>
                      <p>Payment method used for your subscription</p>
                    </div>

                    <button className="billing-action-button">
                      Change
                    </button>
                  </div>

                  <div className="payment-method">
                    <div className="payment-icon">
                      ₹
                    </div>

                    <div>
                      <strong>UPI Payment</strong>
                      <span>cliently@upi</span>
                    </div>
                  </div>
                </div>

                <div className="billing-section">
                  <div className="billing-section-header">
                    <div>
                      <h3>Billing History</h3>
                      <p>View your previous subscription payments</p>
                    </div>
                  </div>

                  <div className="billing-table-wrapper">
                    <table className="billing-table">
                      <thead>
                        <tr>
                          <th>DATE</th>
                          <th>AMOUNT</th>
                          <th>STATUS</th>
                          <th>ACTION</th>
                        </tr>
                      </thead>

                      <tbody>
                        {billingHistory.map((bill) => (
                          <tr key={bill.id}>
                            <td>{bill.date}</td>

                            <td className="billing-amount">
                              {bill.amount}
                            </td>

                            <td>
                              <span className="billing-paid">
                                {bill.status}
                              </span>
                            </td>

                            <td>
                              <button className="billing-invoice-button">
                                View Invoice
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>
      </section>
    </main>
  )
}

export default Settings